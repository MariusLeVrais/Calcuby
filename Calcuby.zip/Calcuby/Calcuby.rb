#Calc code in Ruby by Marius

print("Welcome to CalculaRuby\n")
print("\n1.Addition\n")
print("2.Soustraction\n")
print("3.Multiplication\n")
print("4.Division\n")
print("5.Features\n")
print("\nEnter the number of operation : ")
choose = gets.chomp("\n")
if choose == "1"
    print("\nPlease enter the first number : ")
    input1 = gets.chomp.to_i()
    print("\nPlease enter the second number : ")
    input2 = gets.chomp.to_i()
    add = input1 + input2
    print("\nThe result is : ", add)
    gets.chomp.to_i()
end
if choose == "2"
    print("\nPlease enter the first number : ")
    input3 = gets.chomp.to_i()
    print("\nPlease enter the second number : ")
    input4 = gets.chomp.to_i()
    sous = input3 - input4
    print("\nThe result is : ", sous)
    gets.chomp.to_i()
end
if choose == "3"
    print("\nPlease enter the first number : ")
    input5 = gets.chomp.to_i()
    print("\nPlease enter the second number : ")
    input6 = gets.chomp.to_i()
    mult = input5 * input6
    print("\nThe result is : ", mult)
    gets.chomp.to_i()
end
if choose == "4"
    print("\nPlease enter the first number : ")
    input7 = gets.chomp.to_i()
    print("\nPlease enter the second number : ")
    input8 = gets.chomp.to_i()
    div = input7 / input8
    print("\nThe result is : ", div)
    gets.chomp.to_i()
end
if choose == "5"
    print("1.Aire")
    print("\n2.Modulo")
    print("\nEnter the number of calcul : ")
    input9 = gets.chomp("")
    if input9 == "1"
        print("\nPlease enter the number : ")
        input10 = gets.chomp.to_i()
        aires = input10 * input10
        print("\nThe result is : ", aires)
        gets.chomp.to_i()
    end
    if input9 == "2"
        print("\nPlease enter the first number : ")
        input11 = gets.chomp.to_i()
        print("\nPlease enter the second number : ")
        input12 = gets.chomp.to_i()
        modulo = input11 % input12
        print("\nThe result is : ", modulo)
        gets.chomp.to_i()
    end
end


